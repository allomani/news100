-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jun 17, 2009 at 07:30 AM
-- Server version: 4.0.26
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `news_en`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `events_data`
-- 

CREATE TABLE `events_data` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `content` text NOT NULL,
  `day` int(11) NOT NULL default '0',
  `month` int(11) NOT NULL default '0',
  `year` int(11) NOT NULL default '0',
  `typeid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `events_data`
-- 

INSERT INTO `events_data` (`id`, `name`, `content`, `day`, `month`, `year`, `typeid`) VALUES (1, 'Test', '<HTML><HEAD></HEAD>\r\n<BODY>\r\n<DIV dir=rtl align=center><SPAN style="FONT-WEIGHT: bold">Test</SPAN></DIV></BODY></HTML>', 7, 3, 2008, 1);
INSERT INTO `events_data` (`id`, `name`, `content`, `day`, `month`, `year`, `typeid`) VALUES (2, 'test', '<div dir="rtl">test</div>', 5, 3, 2008, 2);
INSERT INTO `events_data` (`id`, `name`, `content`, `day`, `month`, `year`, `typeid`) VALUES (3, 'karma Band at El Sakia', '<HTML><HEAD></HEAD>\r\n<BODY>\r\n<P align=center><SPAN style="FONT-WEIGHT: bold"><IMG id=ctl00_ContentPlaceHolder2_rptEventInfo_ctl00_imgEvent title="karma Band at El Sakia" style="BORDER-TOP-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px" src="http://www.yallabina.com/Events/UploadedFiles/rock4-main10-4-2008-14-44-52.jpg"></SPAN></P>\r\n<DIV><SPAN style="FONT-WEIGHT: bold"></SPAN>&nbsp;</DIV>\r\n<DIV><SPAN style="FONT-WEIGHT: bold">Type :</SPAN> Rock Music </DIV>\r\n<P><SPAN style="FONT-WEIGHT: bold">Where: </SPAN>26th of July St. ,Zamalek </P>\r\n<P><SPAN style="FONT-WEIGHT: bold">Occurrence:</SPAN> Once </P>\r\n<P></P>\r\n<P><SPAN style="FONT-WEIGHT: bold">Doors Open: </SPAN>8:30pm <SPAN style="FONT-WEIGHT: bold">To: </SPAN>10:30pm </P>\r\n<H3>Tickets</H3>\r\n<P><SPAN style="FONT-WEIGHT: bold">Regular :</SPAN> 20 L.E. </P>\r\n<DIV>&nbsp;</DIV>\r\n<DIV>karma Band performing some rock songs at El Sakia''s River Hall&nbsp;on the 14th of April</DIV></BODY></HTML>', 14, 4, 2008, 2);

-- --------------------------------------------------------

-- 
-- Table structure for table `events_types`
-- 

CREATE TABLE `events_types` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `color` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `events_types`
-- 

INSERT INTO `events_types` (`id`, `name`, `color`) VALUES (1, 'indoor', '#EEEEE');
INSERT INTO `events_types` (`id`, `name`, `color`) VALUES (2, 'outdoor', '#EEDEE');

-- --------------------------------------------------------

-- 
-- Table structure for table `info_best_visitors`
-- 

CREATE TABLE `info_best_visitors` (
  `time` text NOT NULL,
  `v_count` int(11) NOT NULL default '0'
) ENGINE=MYISAM;

-- 
-- Dumping data for table `info_best_visitors`
-- 

INSERT INTO `info_best_visitors` (`time`, `v_count`) VALUES ('19-Apr-2008  Time : 13:48', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `info_browser`
-- 

CREATE TABLE `info_browser` (
  `name` text NOT NULL,
  `count` int(11) NOT NULL default '0'
) ENGINE=MYISAM;

-- 
-- Dumping data for table `info_browser`
-- 

INSERT INTO `info_browser` (`name`, `count`) VALUES ('Netscape', 0);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('MSIE', 2609);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('Lynx', 0);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('Opera', 0);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('WebTV', 0);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('Konqueror', 0);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('Bot', 0);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('Other', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `info_hits`
-- 

CREATE TABLE `info_hits` (
  `date` text NOT NULL,
  `hits` int(11) NOT NULL default '0'
) ENGINE=MYISAM;

-- 
-- Dumping data for table `info_hits`
-- 

INSERT INTO `info_hits` (`date`, `hits`) VALUES ('02-04-2008', 236);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('03-04-2008', 66);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('04-04-2008', 210);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('05-04-2008', 402);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('06-04-2008', 339);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('07-04-2008', 38);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('08-04-2008', 185);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('09-04-2008', 294);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('13-04-2008', 188);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('17-04-2008', 14);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('19-04-2008', 483);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('22-04-2008', 120);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('21-05-2008', 22);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('10-07-2008', 2);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('22-09-2008', 2);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('21-11-2008', 3);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('17-06-2009', 5);

-- --------------------------------------------------------

-- 
-- Table structure for table `info_online`
-- 

CREATE TABLE `info_online` (
  `time` int(15) NOT NULL default '0',
  `ip` varchar(40) NOT NULL default '',
  PRIMARY KEY  (`time`),
  KEY `ip` (`ip`)
) ENGINE=MYISAM;

-- 
-- Dumping data for table `info_online`
-- 

INSERT INTO `info_online` (`time`, `ip`) VALUES (1245213034, '127.0.0.1');

-- --------------------------------------------------------

-- 
-- Table structure for table `info_os`
-- 

CREATE TABLE `info_os` (
  `name` text NOT NULL,
  `count` int(11) NOT NULL default '0'
) ENGINE=MYISAM;

-- 
-- Dumping data for table `info_os`
-- 

INSERT INTO `info_os` (`name`, `count`) VALUES ('Windows', 2609);
INSERT INTO `info_os` (`name`, `count`) VALUES ('Mac', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('Linux', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('FreeBSD', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('SunOS', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('IRIX', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('BeOS', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('OS/2', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('AIX', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('Other', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `news_banners`
-- 

CREATE TABLE `news_banners` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `url` text NOT NULL,
  `img` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `ord` int(11) NOT NULL default '0',
  `type` text NOT NULL,
  `views` int(11) NOT NULL default '0',
  `clicks` int(11) NOT NULL default '0',
  `menu_id` int(11) NOT NULL default '0',
  `menu_pos` text NOT NULL,
  `pages` text NOT NULL,
  `content` text NOT NULL,
  `c_type` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `news_banners`
-- 

INSERT INTO `news_banners` (`id`, `title`, `url`, `img`, `date`, `ord`, `type`, `views`, `clicks`, `menu_id`, `menu_pos`, `pages`, `content`, `c_type`) VALUES (1, 'Allomani', '', '', '2006-06-10 01:00:00', 1, 'footer', 15460, 29, 0, 'l', 'main,browse,news,pages,search,votes,statics,browse_events,photos,', '<center><a href=''http://allomani.biz'' target=_blank><img src=''http://allomani.biz/allomani_banner.gif'' border=0></a></center>', 'code');
INSERT INTO `news_banners` (`id`, `title`, `url`, `img`, `date`, `ord`, `type`, `views`, `clicks`, `menu_id`, `menu_pos`, `pages`, `content`, `c_type`) VALUES (2, 'Allomani', 'http://allomani.biz/', 'http://allomani.biz/allomani_banner.gif', '0000-00-00 00:00:00', 0, 'header', 15488, 15, 0, 'l', 'main,browse,news,pages,search,votes,statics,browse_events,photos,', '', 'img');

-- --------------------------------------------------------

-- 
-- Table structure for table `news_blocks`
-- 

CREATE TABLE `news_blocks` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `pos` text NOT NULL,
  `file` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `template` int(11) NOT NULL default '0',
  `pages` text NOT NULL,
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `file` (`file`),
  FULLTEXT KEY `file_2` (`file`),
  FULLTEXT KEY `file_3` (`file`),
  FULLTEXT KEY `file_4` (`file`),
  FULLTEXT KEY `file_5` (`file`),
  FULLTEXT KEY `file_6` (`file`),
  FULLTEXT KEY `file_7` (`file`),
  FULLTEXT KEY `file_8` (`file`)
) ENGINE=MYISAM AUTO_INCREMENT=1718 ;

-- 
-- Dumping data for table `news_blocks`
-- 

INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (10, 'Search', 'r', '<form method="get" action="index.php">\r\n<input type=text name="keyword" size="12" tabindex="1">\r\n<input type=hidden name="action" value="search">\r\n<input type=submit value="Search" tabindex="1">\r\n</form>', 7, 1, 0, 'main,browse,news,pages,search,votes,statics,browse_events,photos,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (8, 'Main Menu', 'r', '<b>::</b> <a href=''index.php''>Home</a><br>\r\n<b>::</b> <a href=''browse.html''>News Archive</a><br>\r\n<b>::</b> <a href=''index.php?action=photos''>Photo Album</a><br>\r\n<b>::</b> <a href=''index.php?action=browse_events''>Events</a><br>\r\n<b>::</b> <a href=''rss.php''>RSS Feed</a><br>\r\n<b>::</b> <a href=''index.php?action=statics''>Statics</a><br>\r\n<b>::</b> <a href=''index.php?action=contactus''>Contact Us</a><br>\r\n ', 1, 1, 0, 'main,browse,news,pages,search,votes,statics,browse_events,photos,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (17, 'Main Categories', 'r', '<?\r\n$cats_qr=db_query("select * from news_cats where cat=0");\r\nwhile($data = db_fetch($cats_qr)){\r\n       print "<b>::</b> <a href=''browse_$data[id].html''>$data[name]</a><br>";\r\n\r\n\r\n        }\r\n', 2, 1, 0, 'main,browse,news,pages,search,votes,statics,browse_events,photos,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (11, 'Votes', 'l', '<?\r\n$qr_title = db_query("select * from news_votes_cats  where active=1");\r\nif(db_num($qr_title)){\r\n\r\n$data_title = db_fetch($qr_title);\r\nprint "<center>$data_title[title]</center>";\r\n$qr = mysql_query("select * from news_votes where cat=$data_title[id]");\r\nprint "<form action=\\"index.php\\" method=\\"post\\">\r\n<input type=''hidden'' name=''action'' value=''vote_add''>\r\n";\r\n\r\n while ($data = mysql_fetch_array($qr)){\r\n\r\n        print "<input type=''radio'' value=''$data[id]'' name=''vote_id''>$data[title]<br>";\r\n\r\n\r\n\r\n }\r\nprint "<center><br><input type=''submit'' value=''Vote''> <br><br><a href=''index.php?action=votes''>Results</a></center></form>";\r\n}else{\r\nprint "<center> No Active Votes</center>";\r\n}\r\n?>', 3, 1, 0, 'main,browse,news,pages,search,votes,statics,browse_events,photos,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (4, 'Now Online', 'r', '<?\r\nglobal $counter ;\r\n\r\nprint "<p align=center>  Now Browsing $counter[online_users] Visitor</p>";\r\n\r\nprint "<p dir=ltr align=center>Most Visits was $counter[best_visit] Visitor in : <br> $counter[best_visit_time] <br></p>";\r\n\r\n', 6, 1, 0, 'main,browse,news,pages,search,votes,statics,browse_events,photos,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (18, 'Last News', 'c', '<?\r\nglobal $preview_text_limit;\r\n$qr = db_query("select id,title,date,writer,img,left(details,".$preview_text_limit.") as details from news_news order by id DESC limit 4");\r\n                            print "<hr width=90% style=\\"border:1px dashed #336699; \\" size=\\"1\\"> ";\r\nwhile($data = db_fetch($qr)){\r\n\r\n\r\n\r\n     print "\r\n     <table width=100%><tr><td width=20%><img src=''".get_image($data[''img''])."$img_ur''></td>\r\n     <td><center><font color=''#808080'' class=''title''>$data[title]</font></center><br><font color=''#808080''>".date("d-m-Y",strtotime($data[''date''])).": </font>".\r\n     getPreviewText("$data[details]") ."... <a href=''news-$data[id].html''>More </a>\r\n     <br><br> Writer : <font color=''#808080''>$data[writer]</font></td></tr></table>\r\n     <hr width=90% style=\\"border:1px dashed #336699; \\" size=\\"1\\">";\r\n\r\n        }\r\n\r\n       ?>', 2, 1, 0, 'main,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (32, 'Last News', 'l', '<?\r\nglobal $cat,$id,$action;\r\nif($action=="browse" && $cat){\r\n$cat_id = $cat;\r\n$cat_qr = "where cat=''$cat_id''";\r\n}elseif($action=="news"){\r\n$dt_cat = db_qr_fetch("select cat from news_news where id=''$id''");\r\n$cat_id =$dt_cat[''cat'']; \r\n$cat_qr = "where cat=''$cat_id''";\r\n}else{\r\n$cat_qr =   "";\r\n}\r\n\r\n$qr = db_query("select * from news_news $cat_qr order by id DESC limit 20");\r\n\r\n\r\nwhile($data=db_fetch($qr)){\r\n\r\n\r\nprint "<li><a href=''news-$data[id].html''  onmouseover=\\"balloon.showTooltip(event,''<div id=ShowTopic-$data[id]></div>'',null,300);sam($data[id],''short-$data[id].html'');\\">$data[title]</a></li>";\r\n}\r\n', 1, 1, 0, 'browse,news,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (33, 'Last News', 'c', '<?\r\nglobal $preview_text_limit;\r\n\r\n$c = 0 ;\r\nprint "<table width=100% dir=rtl><tr>"  ;\r\n                             $qr_cat=mysql_query("select * from news_cats order by id");\r\n                              while($data_cat = db_fetch($qr_cat)){\r\n\r\n                                   ++$c ;\r\n\r\nif ($c==''3'') {\r\nprint "  </tr><TR>" ;\r\n$c = 1 ;\r\n}\r\n                                    print "<td width=50% valign=top>";\r\n                                                                        print "<p align=center class=title>$data_cat[name]</p>";\r\n                                      $qr = db_query("select id,title,date,writer,img,left(details,".$preview_text_limit.") as details from news_news where cat=$data_cat[id] order by id DESC limit 2");\r\n                            print "<hr width=90% style=\\"border:1px dashed #336699; \\" size=\\"1\\"> ";\r\nif(db_num($qr)){\r\nwhile($data = db_fetch($qr)){\r\n\r\n\r\n\r\n     print "\r\n     <table width=100%><tr><td width=20%><img src=''".get_image($data[''img''])."$img_ur''></td>\r\n     <td><center><font color=''#808080'' size=4><b>$data[title]</b></font></center><br> <font color=''#808080''>".date("d-m-Y",strtotime($data[''date''])).": </font>".\r\n     getPreviewText("$data[details]") ." ... <a href=''news-$data[id].html''>More </a>\r\n     <br><br> Writer  : <font color=''#808080''>$data[writer]</font></td></tr></table>\r\n     <hr width=90% style=\\"border:1px dashed #336699; \\" size=\\"1\\">";\r\n\r\n        }\r\n                                     print "<p align=left><a href=''browse_$data_cat[id].html''>More </a></p>" ;\r\n}else{\r\nprint "<center>  No News  </center><br>\r\n <hr width=90% style=\\"border:1px dashed #336699; \\" size=\\"1\\"><br>" ;\r\n}\r\n                                 print "</td>";\r\n                                      }\r\n                                    \r\nprint "</table>";\r\n?>', 1, 1, 0, 'main,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (34, 'Most Viewed', 'l', '<?\r\n$qr = db_query("select * from news_news order by views DESC limit 20");\r\n\r\n\r\nwhile($data=db_fetch($qr)){\r\n\r\n\r\nprint "<li><a href=''news-$data[id].html''  onmouseover=\\"balloon.showTooltip(event,''<div id=ShowTopic-$data[id]></div>'',null,300);sam($data[id],''short-$data[id].html'');\\">$data[title]</a></li>";\r\n}\r\n?>\r\n', 5, 1, 0, 'main,browse,news,pages,search,votes,statics,browse_events,photos,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (22, 'Most Voted', 'l', '<?\r\n\r\n$qr = db_query("select *  from news_news where votes > 0 order by (votes / votes_total) DESC limit 10");\r\n\r\n\r\nwhile($data=db_fetch($qr)){\r\n\r\n\r\nprint "<li><a href=''news-$data[id].html''  onmouseover=\\"balloon.showTooltip(event,''<div id=ShowTopic-$data[id]></div>'',null,300);sam($data[id],''short-$data[id].html'');\\">$data[title]</a></li>";\r\n}\r\n?>\r\n', 4, 1, 0, 'main,browse,news,pages,search,votes,statics,browse_events,photos,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (35, 'Rss Feed', 'r', '<center><a href=''rss.php''><img border=0 src=''images/rss.gif''></a></center>', 4, 1, 0, 'main,browse,news,pages,search,votes,statics,browse_events,photos,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (23, 'Statics', 'r', '<?\r\n $data1 = db_qr_fetch("select count(id) as count from news_news");\r\n  $data3 = db_qr_fetch("select count(id) as count from news_cats where cat=0");\r\n \r\n\r\nprint "\r\n\r\n<li><b> News Count: </b> $data1[count]</li>\r\n<li> <b> Main Categories: </b> $data3[count] </li>\r\n";\r\n?>', 5, 1, 0, 'main,browse,news,pages,search,votes,statics,browse_events,photos,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (24, 'Custom News', 'l', '<?\r\n$qr = db_query("select * from news_new_menu order by id DESC");\r\n\r\n\r\nwhile($data=db_fetch($qr)){\r\n\r\n$data2=db_qr_fetch("select * from news_news where id=$data[news_id]");\r\n\r\nprint "<li><a href=''news-$data2[id].html'' onmouseover=\\"balloon.showTooltip(event,''<div id=ShowTopic-$data2[id]></div>'',null,300);sam($data2[id],''short-$data2[id].html'');\\"\r\n>$data2[title]</a></li>";\r\n}\r\n', 2, 1, 0, 'main,browse,news,pages,search,votes,statics,browse_events,photos,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (36, 'Events', 'r', '<?\r\nrequire_once ("plugins/events/calendar.class.php");\r\n\r\n\r\nif($_GET[''calmonth''] == '''')\r\n$month = date("m");\r\nelse\r\n$month = intval($_GET[''calmonth'']);\r\nif($_GET[''calyear''] == '''')\r\n$year = date("Y");\r\nelse\r\n$year = intval($_GET[''calyear'']);;\r\n\r\n\r\n$MyCal = new calendar(''auto'', ''auto'', ''en'');\r\n\r\n$MyCal->monday_1st = ''1'';\r\n\r\n\r\n$query = mysql_query("SELECT * FROM events_data WHERE month=''$month'' and year=''$year''");\r\n// Thanks to this loop, we get a string ($DAYS) in which are the days when something have been added to the sql table\r\n// Please note the numbers in the string must be separated by a '':'' (ex: ''02:09:15:29'')\r\nwhile ($fetch = mysql_fetch_array($query)) {\r\n    $day = $fetch[''day''];\r\n    $DAYS .= $day . '':'';\r\n}\r\n// Deletes the final '':''\r\n$DAYS = substr($DAYS, 0, -1);\r\n// We call the links() function : we give first the string in which are the days and then the pattern of the link\r\n// {D} = the linked day\r\n// {M} = the month of the calendar\r\n// {Y} = the year of the calendar\r\n$MyCal->links($DAYS, "index.php?action=browse_events&d={D}&amp;m={M}&amp;y={Y}");\r\n// We call the generate() function, all is in its name\r\n\r\n$MyCal->generate();\r\n// We call the draw() function which allow you to display the calendar generated before\r\n$MyCal->draw();\r\n', 3, 1, 0, 'main,browse,news,pages,search,votes,statics,browse_events,photos,');
INSERT INTO `news_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (37, 'New Photos', 'c', '<?\r\nglobal $settings,$phrases;\r\n\r\n$qr = db_query("select * from photos_data order by id desc limit 9");\r\n    print "<center><table width=100%>" ;\r\n    $c=0;\r\n        while($data = db_fetch($qr)){\r\n\r\n\r\n\r\nif ($c==$settings[''photos_cells'']) {\r\nprint "  </tr><TR>" ;\r\n$c = 0 ;\r\n}\r\n    ++$c ;\r\nprint " <td><center><a href=''$data[img]'' target=_blank>\r\n            <img border=0 alt=''$phrases[add_date] : ".substr($data[''date''],0,10)."''\r\n            src=''".get_image($data[''thumb''])."''>\r\n             </a><br>$data[name]";\r\n\r\n print "</center>    </td>";\r\n           }\r\n           print "</tr></table></center>";', 3, 1, 0, 'main,');

-- --------------------------------------------------------

-- 
-- Table structure for table `news_cats`
-- 

CREATE TABLE `news_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `news_cats`
-- 

INSERT INTO `news_cats` (`id`, `name`, `cat`) VALUES (7, 'Business', 0);
INSERT INTO `news_cats` (`id`, `name`, `cat`) VALUES (2, 'Science/Nature', 0);
INSERT INTO `news_cats` (`id`, `name`, `cat`) VALUES (9, 'Computer', 0);
INSERT INTO `news_cats` (`id`, `name`, `cat`) VALUES (10, 'Health', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `news_countries`
-- 

CREATE TABLE `news_countries` (
  `name` varchar(80) NOT NULL default ''
) ENGINE=MYISAM;

-- 
-- Dumping data for table `news_countries`
-- 

INSERT INTO `news_countries` (`name`) VALUES ('Afghanistan');
INSERT INTO `news_countries` (`name`) VALUES ('Albania');
INSERT INTO `news_countries` (`name`) VALUES ('Algeria');
INSERT INTO `news_countries` (`name`) VALUES ('American Samoa');
INSERT INTO `news_countries` (`name`) VALUES ('Andorra');
INSERT INTO `news_countries` (`name`) VALUES ('Angola');
INSERT INTO `news_countries` (`name`) VALUES ('Anguilla');
INSERT INTO `news_countries` (`name`) VALUES ('Antarctica');
INSERT INTO `news_countries` (`name`) VALUES ('Antigua and Barbuda');
INSERT INTO `news_countries` (`name`) VALUES ('Argentina');
INSERT INTO `news_countries` (`name`) VALUES ('Armenia');
INSERT INTO `news_countries` (`name`) VALUES ('Aruba');
INSERT INTO `news_countries` (`name`) VALUES ('Australia');
INSERT INTO `news_countries` (`name`) VALUES ('Austria');
INSERT INTO `news_countries` (`name`) VALUES ('Azerbaijan');
INSERT INTO `news_countries` (`name`) VALUES ('Bahamas');
INSERT INTO `news_countries` (`name`) VALUES ('Bahrain');
INSERT INTO `news_countries` (`name`) VALUES ('Bangladesh');
INSERT INTO `news_countries` (`name`) VALUES ('Barbados');
INSERT INTO `news_countries` (`name`) VALUES ('Belarus');
INSERT INTO `news_countries` (`name`) VALUES ('Belgium');
INSERT INTO `news_countries` (`name`) VALUES ('Belize');
INSERT INTO `news_countries` (`name`) VALUES ('Benin');
INSERT INTO `news_countries` (`name`) VALUES ('Bermuda');
INSERT INTO `news_countries` (`name`) VALUES ('Bhutan');
INSERT INTO `news_countries` (`name`) VALUES ('Bolivia');
INSERT INTO `news_countries` (`name`) VALUES ('Bosnia and Herzegovina');
INSERT INTO `news_countries` (`name`) VALUES ('Botswana');
INSERT INTO `news_countries` (`name`) VALUES ('Bouvet Island');
INSERT INTO `news_countries` (`name`) VALUES ('Brazil');
INSERT INTO `news_countries` (`name`) VALUES ('British Indian Ocean Territory');
INSERT INTO `news_countries` (`name`) VALUES ('Brunei Darussalam');
INSERT INTO `news_countries` (`name`) VALUES ('Bulgaria');
INSERT INTO `news_countries` (`name`) VALUES ('Burkina Faso');
INSERT INTO `news_countries` (`name`) VALUES ('Burundi');
INSERT INTO `news_countries` (`name`) VALUES ('Cambodia');
INSERT INTO `news_countries` (`name`) VALUES ('Cameroon');
INSERT INTO `news_countries` (`name`) VALUES ('Canada');
INSERT INTO `news_countries` (`name`) VALUES ('Cape Verde');
INSERT INTO `news_countries` (`name`) VALUES ('Cayman Islands');
INSERT INTO `news_countries` (`name`) VALUES ('Central African Republic');
INSERT INTO `news_countries` (`name`) VALUES ('Chad');
INSERT INTO `news_countries` (`name`) VALUES ('Chile');
INSERT INTO `news_countries` (`name`) VALUES ('China');
INSERT INTO `news_countries` (`name`) VALUES ('Christmas Island');
INSERT INTO `news_countries` (`name`) VALUES ('Cocos (Keeling) Islands');
INSERT INTO `news_countries` (`name`) VALUES ('Colombia');
INSERT INTO `news_countries` (`name`) VALUES ('Comoros');
INSERT INTO `news_countries` (`name`) VALUES ('Congo');
INSERT INTO `news_countries` (`name`) VALUES ('Cook Islands');
INSERT INTO `news_countries` (`name`) VALUES ('Costa Rica');
INSERT INTO `news_countries` (`name`) VALUES ('Cote D''Ivoire');
INSERT INTO `news_countries` (`name`) VALUES ('Croatia');
INSERT INTO `news_countries` (`name`) VALUES ('Cuba');
INSERT INTO `news_countries` (`name`) VALUES ('Cyprus');
INSERT INTO `news_countries` (`name`) VALUES ('Czech Republic');
INSERT INTO `news_countries` (`name`) VALUES ('Denmark');
INSERT INTO `news_countries` (`name`) VALUES ('Djibouti');
INSERT INTO `news_countries` (`name`) VALUES ('Dominica');
INSERT INTO `news_countries` (`name`) VALUES ('Dominican Republic');
INSERT INTO `news_countries` (`name`) VALUES ('Ecuador');
INSERT INTO `news_countries` (`name`) VALUES ('Egypt');
INSERT INTO `news_countries` (`name`) VALUES ('El Salvador');
INSERT INTO `news_countries` (`name`) VALUES ('Equatorial Guinea');
INSERT INTO `news_countries` (`name`) VALUES ('Eritrea');
INSERT INTO `news_countries` (`name`) VALUES ('Estonia');
INSERT INTO `news_countries` (`name`) VALUES ('Ethiopia');
INSERT INTO `news_countries` (`name`) VALUES ('Faroe Islands');
INSERT INTO `news_countries` (`name`) VALUES ('Fiji');
INSERT INTO `news_countries` (`name`) VALUES ('Finland');
INSERT INTO `news_countries` (`name`) VALUES ('France');
INSERT INTO `news_countries` (`name`) VALUES ('Gabon');
INSERT INTO `news_countries` (`name`) VALUES ('Gambia');
INSERT INTO `news_countries` (`name`) VALUES ('Georgia');
INSERT INTO `news_countries` (`name`) VALUES ('Germany');
INSERT INTO `news_countries` (`name`) VALUES ('Ghana');
INSERT INTO `news_countries` (`name`) VALUES ('Gibraltar');
INSERT INTO `news_countries` (`name`) VALUES ('Greece');
INSERT INTO `news_countries` (`name`) VALUES ('Greenland');
INSERT INTO `news_countries` (`name`) VALUES ('Grenada');
INSERT INTO `news_countries` (`name`) VALUES ('Guadeloupe');
INSERT INTO `news_countries` (`name`) VALUES ('Guam');
INSERT INTO `news_countries` (`name`) VALUES ('Guatemala');
INSERT INTO `news_countries` (`name`) VALUES ('Guinea');
INSERT INTO `news_countries` (`name`) VALUES ('Guinea-Bissau');
INSERT INTO `news_countries` (`name`) VALUES ('Guyana');
INSERT INTO `news_countries` (`name`) VALUES ('Haiti');
INSERT INTO `news_countries` (`name`) VALUES ('Honduras');
INSERT INTO `news_countries` (`name`) VALUES ('Hong Kong');
INSERT INTO `news_countries` (`name`) VALUES ('Hungary');
INSERT INTO `news_countries` (`name`) VALUES ('Iceland');
INSERT INTO `news_countries` (`name`) VALUES ('India');
INSERT INTO `news_countries` (`name`) VALUES ('Indonesia');
INSERT INTO `news_countries` (`name`) VALUES ('Iraq');
INSERT INTO `news_countries` (`name`) VALUES ('Ireland');
INSERT INTO `news_countries` (`name`) VALUES ('Israel');
INSERT INTO `news_countries` (`name`) VALUES ('Italy');
INSERT INTO `news_countries` (`name`) VALUES ('Jamaica');
INSERT INTO `news_countries` (`name`) VALUES ('Japan');
INSERT INTO `news_countries` (`name`) VALUES ('Jordan');
INSERT INTO `news_countries` (`name`) VALUES ('Kazakhstan');
INSERT INTO `news_countries` (`name`) VALUES ('Kenya');
INSERT INTO `news_countries` (`name`) VALUES ('Kiribati');
INSERT INTO `news_countries` (`name`) VALUES ('Korea, Republic of');
INSERT INTO `news_countries` (`name`) VALUES ('Kuwait');
INSERT INTO `news_countries` (`name`) VALUES ('Kyrgyzstan');
INSERT INTO `news_countries` (`name`) VALUES ('Latvia');
INSERT INTO `news_countries` (`name`) VALUES ('Lebanon');
INSERT INTO `news_countries` (`name`) VALUES ('Lesotho');
INSERT INTO `news_countries` (`name`) VALUES ('Liberia');
INSERT INTO `news_countries` (`name`) VALUES ('Libyan Arab Jamahiriya');
INSERT INTO `news_countries` (`name`) VALUES ('Liechtenstein');
INSERT INTO `news_countries` (`name`) VALUES ('Lithuania');
INSERT INTO `news_countries` (`name`) VALUES ('Luxembourg');
INSERT INTO `news_countries` (`name`) VALUES ('Macao');
INSERT INTO `news_countries` (`name`) VALUES ('Madagascar');
INSERT INTO `news_countries` (`name`) VALUES ('Malawi');
INSERT INTO `news_countries` (`name`) VALUES ('Malaysia');
INSERT INTO `news_countries` (`name`) VALUES ('Maldives');
INSERT INTO `news_countries` (`name`) VALUES ('Mali');
INSERT INTO `news_countries` (`name`) VALUES ('Malta');
INSERT INTO `news_countries` (`name`) VALUES ('Marshall Islands');
INSERT INTO `news_countries` (`name`) VALUES ('Martinique');
INSERT INTO `news_countries` (`name`) VALUES ('Mauritania');
INSERT INTO `news_countries` (`name`) VALUES ('Mauritius');
INSERT INTO `news_countries` (`name`) VALUES ('Mayotte');
INSERT INTO `news_countries` (`name`) VALUES ('Mexico');
INSERT INTO `news_countries` (`name`) VALUES ('Monaco');
INSERT INTO `news_countries` (`name`) VALUES ('Mongolia');
INSERT INTO `news_countries` (`name`) VALUES ('Montserrat');
INSERT INTO `news_countries` (`name`) VALUES ('Morocco');
INSERT INTO `news_countries` (`name`) VALUES ('Mozambique');
INSERT INTO `news_countries` (`name`) VALUES ('Myanmar');
INSERT INTO `news_countries` (`name`) VALUES ('Namibia');
INSERT INTO `news_countries` (`name`) VALUES ('Nauru');
INSERT INTO `news_countries` (`name`) VALUES ('Nepal');
INSERT INTO `news_countries` (`name`) VALUES ('Netherlands');
INSERT INTO `news_countries` (`name`) VALUES ('Netherlands Antilles');
INSERT INTO `news_countries` (`name`) VALUES ('New Caledonia');
INSERT INTO `news_countries` (`name`) VALUES ('New Zealand');
INSERT INTO `news_countries` (`name`) VALUES ('Nicaragua');
INSERT INTO `news_countries` (`name`) VALUES ('Niger');
INSERT INTO `news_countries` (`name`) VALUES ('Nigeria');
INSERT INTO `news_countries` (`name`) VALUES ('Niue');
INSERT INTO `news_countries` (`name`) VALUES ('Norfolk Island');
INSERT INTO `news_countries` (`name`) VALUES ('Norway');
INSERT INTO `news_countries` (`name`) VALUES ('Oman');
INSERT INTO `news_countries` (`name`) VALUES ('Pakistan');
INSERT INTO `news_countries` (`name`) VALUES ('Palau');
INSERT INTO `news_countries` (`name`) VALUES ('Panama');
INSERT INTO `news_countries` (`name`) VALUES ('Papua New Guinea');
INSERT INTO `news_countries` (`name`) VALUES ('Paraguay');
INSERT INTO `news_countries` (`name`) VALUES ('Peru');
INSERT INTO `news_countries` (`name`) VALUES ('Philippines');
INSERT INTO `news_countries` (`name`) VALUES ('Pitcairn');
INSERT INTO `news_countries` (`name`) VALUES ('Poland');
INSERT INTO `news_countries` (`name`) VALUES ('Portugal');
INSERT INTO `news_countries` (`name`) VALUES ('Puerto Rico');
INSERT INTO `news_countries` (`name`) VALUES ('Qatar');
INSERT INTO `news_countries` (`name`) VALUES ('Reunion');
INSERT INTO `news_countries` (`name`) VALUES ('Romania');
INSERT INTO `news_countries` (`name`) VALUES ('Russian Federation');
INSERT INTO `news_countries` (`name`) VALUES ('Rwanda');
INSERT INTO `news_countries` (`name`) VALUES ('Saint Helena');
INSERT INTO `news_countries` (`name`) VALUES ('Saint Kitts and Nevis');
INSERT INTO `news_countries` (`name`) VALUES ('Saint Lucia');
INSERT INTO `news_countries` (`name`) VALUES ('Saint Pierre and Miquelon');
INSERT INTO `news_countries` (`name`) VALUES ('Samoa');
INSERT INTO `news_countries` (`name`) VALUES ('San Marino');
INSERT INTO `news_countries` (`name`) VALUES ('Sao Tome and Principe');
INSERT INTO `news_countries` (`name`) VALUES ('Saudi Arabia');
INSERT INTO `news_countries` (`name`) VALUES ('Senegal');
INSERT INTO `news_countries` (`name`) VALUES ('Serbia and Montenegro');
INSERT INTO `news_countries` (`name`) VALUES ('Seychelles');
INSERT INTO `news_countries` (`name`) VALUES ('Sierra Leone');
INSERT INTO `news_countries` (`name`) VALUES ('Singapore');
INSERT INTO `news_countries` (`name`) VALUES ('Slovakia');
INSERT INTO `news_countries` (`name`) VALUES ('Slovenia');
INSERT INTO `news_countries` (`name`) VALUES ('Solomon Islands');
INSERT INTO `news_countries` (`name`) VALUES ('Somalia');
INSERT INTO `news_countries` (`name`) VALUES ('South Africa');
INSERT INTO `news_countries` (`name`) VALUES ('Spain');
INSERT INTO `news_countries` (`name`) VALUES ('Sri Lanka');
INSERT INTO `news_countries` (`name`) VALUES ('Sudan');
INSERT INTO `news_countries` (`name`) VALUES ('Suriname');
INSERT INTO `news_countries` (`name`) VALUES ('Svalbard and Jan Mayen');
INSERT INTO `news_countries` (`name`) VALUES ('Swaziland');
INSERT INTO `news_countries` (`name`) VALUES ('Sweden');
INSERT INTO `news_countries` (`name`) VALUES ('Switzerland');
INSERT INTO `news_countries` (`name`) VALUES ('Syrian Arab Republic');
INSERT INTO `news_countries` (`name`) VALUES ('Taiwan, Province of China');
INSERT INTO `news_countries` (`name`) VALUES ('Tajikistan');
INSERT INTO `news_countries` (`name`) VALUES ('Thailand');
INSERT INTO `news_countries` (`name`) VALUES ('Timor-Leste');
INSERT INTO `news_countries` (`name`) VALUES ('Togo');
INSERT INTO `news_countries` (`name`) VALUES ('Tokelau');
INSERT INTO `news_countries` (`name`) VALUES ('Tonga');
INSERT INTO `news_countries` (`name`) VALUES ('Trinidad and Tobago');
INSERT INTO `news_countries` (`name`) VALUES ('Tunisia');
INSERT INTO `news_countries` (`name`) VALUES ('Turkey');
INSERT INTO `news_countries` (`name`) VALUES ('Turkmenistan');
INSERT INTO `news_countries` (`name`) VALUES ('Turks and Caicos Islands');
INSERT INTO `news_countries` (`name`) VALUES ('Tuvalu');
INSERT INTO `news_countries` (`name`) VALUES ('Uganda');
INSERT INTO `news_countries` (`name`) VALUES ('Ukraine');
INSERT INTO `news_countries` (`name`) VALUES ('United Arab Emirates');
INSERT INTO `news_countries` (`name`) VALUES ('United Kingdom');
INSERT INTO `news_countries` (`name`) VALUES ('United States');
INSERT INTO `news_countries` (`name`) VALUES ('Uruguay');
INSERT INTO `news_countries` (`name`) VALUES ('Uzbekistan');
INSERT INTO `news_countries` (`name`) VALUES ('Vanuatu');
INSERT INTO `news_countries` (`name`) VALUES ('Venezuela');
INSERT INTO `news_countries` (`name`) VALUES ('Viet Nam');
INSERT INTO `news_countries` (`name`) VALUES ('Virgin Islands, British');
INSERT INTO `news_countries` (`name`) VALUES ('Virgin Islands, U.s.');
INSERT INTO `news_countries` (`name`) VALUES ('Wallis and Futuna');
INSERT INTO `news_countries` (`name`) VALUES ('Western Sahara');
INSERT INTO `news_countries` (`name`) VALUES ('Yemen');
INSERT INTO `news_countries` (`name`) VALUES ('Zambia');
INSERT INTO `news_countries` (`name`) VALUES ('Zimbabwe');
INSERT INTO `news_countries` (`name`) VALUES ('Palestine');

-- --------------------------------------------------------

-- 
-- Table structure for table `news_news`
-- 

CREATE TABLE `news_news` (
  `id` int(11) NOT NULL auto_increment,
  `writer` text NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `details` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `img` text NOT NULL,
  `timeout` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=30 ;

-- 
-- Dumping data for table `news_news`
-- 

INSERT INTO `news_news` (`id`, `writer`, `title`, `content`, `details`, `date`, `img`, `timeout`, `cat`, `views`, `votes`, `votes_total`) VALUES (24, 'BBC', 'Paypal to block ''unsafe browsers'' ', '', '<HTML><HEAD></HEAD>\r\n<BODY>\r\n<P class=first><SPAN style="FONT-WEIGHT: bold">Web payment firm Paypal has said it will block "unsafe browsers" from using its service as part of wider anti-phishing efforts.</SPAN> \r\n<P>Customers will first be warned that a browser is unsafe but could then be blocked if they continue using it. \r\n<P>Paypal said it was "an alarming fact that there is a significant set of users who use very old and vulnerable browsers such as Internet Explorer 4". \r\n<P>Phishing attacks trick users into handing over sensitive data. <!-- E SF -->\r\n<P>Paypal said some users were still using Internet Explorer 3 , released more than 10 years ago. It lacks many of the security and safety features needed to protect users from phishing and other online attacks. \r\n<P><SPAN style="FONT-WEIGHT: bold">Legitimate sites</SPAN> \r\n<P>Paypal said it supported the use of Extended Validation SSL Certificates. Browsers which support the technology highlight the address bar in green when users are on a site that has been deemed legitimate. \r\n<P>The latest version of Internet Explorer support EV SSL certificates, while Firefox 2 supports it with an add-on but Apple''s Safari browser for Mac and PCs does not. \r\n<P>"By displaying the green glow and company name, these newer browsers make it much easier for users to determine whether or not they''re on the site that they thought they were visiting," said Paypal. \r\n<P>The steps were outlined in a white paper on managing phishing, written by the firm''s chief information security officer Michael Barrett and Dan Levy, director of risk management. \r\n<P>In it, they said: "In our view letting users view the PayPal site on [an unsafe] browser is equal to a car manufacturer allowing drivers to buy one of their vehicles without seatbelts." \r\n<P>Paypal described the battle against phishing as a "fast-moving chess match with the criminal community". </P></BODY></HTML>', '2008-04-22 17:46:41', 'uploads/news/44580203_paypal226_thumb.gif', 0, 9, 2, 0, 0);
INSERT INTO `news_news` (`id`, `writer`, `title`, `content`, `details`, `date`, `img`, `timeout`, `cat`, `views`, `votes`, `votes_total`) VALUES (25, 'BBC', 'Web 2.0 is set for spending boom', '', '<HTML><HEAD></HEAD>\r\n<BODY>\r\n<P class=first><SPAN style="FONT-WEIGHT: bold">Web 2.0 is set to be embraced by Enterprise 2.0 as businesses prepare to spend nearly $5 billion by 2013 on social networking tools.</SPAN> \r\n<P>Over half of the companies in North America and Europe see Web 2.0 as a priority for next year, a report says. \r\n<P>The news comes as San Francisco plays host to the Web 2.0 conference on next generation of the web. \r\n<P>"This is where we see the future of the web," said conference co-chair Jennifer Pahlka. <!-- E SF -->\r\n<P>"The companies making announcements here are building that future." \r\n<P>Forrester, the research company which carried out the Web 2.0 survey, believes the technologies being developed and unveiled over the coming days represent "a fundamentally new way" for businesses to communicate with employees and customers. \r\n<P><SPAN style="FONT-WEIGHT: bold">Priority</SPAN> \r\n<P>The report found that consumer giants such as General Motors, McDonald''s, Northwestern Mutual Life Insurance and Wells Fargo Bank will drive much of this growth and have already embraced tools like blogs, RSS feeds, podcasting and social networking. \r\n<DIV>Analyst Oliver Young estimates that another 56% of North American and European companies regard Web 2.0 to be a priority in 2008. </DIV>\r\n<DIV>&nbsp;</DIV>\r\n<DIV>&nbsp;</DIV></BODY></HTML>', '2008-04-22 17:49:39', 'uploads/news/44588860_keyboard66.jpg', 0, 9, 1, 1, 1);
INSERT INTO `news_news` (`id`, `writer`, `title`, `content`, `details`, `date`, `img`, `timeout`, `cat`, `views`, `votes`, `votes_total`) VALUES (26, 'BBC', 'RBS sets out �12bn rights issue', '', '<HTML><HEAD></HEAD>\r\n<BODY>\r\n<P class=first><SPAN style="FONT-WEIGHT: bold">Royal Bank of Scotland (RBS), the UK''s second-biggest banking group, is asking shareholders for an extra �12bn to shore up its finances.</SPAN> \r\n<P>The rights issue was announced as part of a trading update and is one of the largest seen in UK corporate history. \r\n<P>The firm also announced a write-down of �5.9bn before tax, following its exposure to the credit markets. \r\n<DIV>BBC business editor Robert Peston said other banks may well follow suit, to reinforce their financial foundations. </DIV>\r\n<DIV>&nbsp;</DIV>\r\n<DIV>\r\n<P>Mr Peston also said RBS would "retain more capital in its balance sheet to meet the risks of default by borrowers than it had been doing". \r\n<P>Richard Hunter, head of UK equities at Hargreaves Lansdown Stockbrokers, said: "RBS may have lost the element of surprise as the news was well flagged, but will nonetheless benefit from being first to the plate as this announcement will inevitably lead to cash calls from others". \r\n<P>Analysts speculate that Barclays and HBOS could also be possible candidates for rights issues. </P><!-- E SF --></DIV></BODY></HTML>', '2008-04-22 17:55:36', 'uploads/news/44588814_rbspa66jpg.jpg', 0, 7, 1, 0, 0);
INSERT INTO `news_news` (`id`, `writer`, `title`, `content`, `details`, `date`, `img`, `timeout`, `cat`, `views`, `votes`, `votes_total`) VALUES (27, 'BBC', 'Airbus raises prices of aircraft ', '', '<HTML><HEAD></HEAD>\r\n<BODY>\r\n<P class=first><SPAN style="FONT-WEIGHT: bold">Airbus has announced a rise in prices across its range of aircraft, blaming rising metals prices and the weakness of the US dollar.</SPAN> \r\n<P>The list prices of single-aisle planes will rise $2m (�1m) while wide-body, long range and A380 aircraft will go up $4m on top of the annual rise of 2.74%. \r\n<P>Prices paid for aircraft vary based on the specifications of the aircraft and also the deal reached by the airline. \r\n<P>The average price for an A380 is $327.4m while an A320 is $76.9m. <!-- E SF -->\r\n<P>"We have to keep pace with the world market price developments and secure profitable deals," said John Leahy at Airbus. \r\n<P><SPAN style="FONT-WEIGHT: bold">Climate change</SPAN> \r\n<P>Also on Tuesday, Airbus was among the signatories to a pledge to address the aviation industry''s impact on climate change. \r\n<P>It was also signed by Boeing, the engine-makers Rolls Royce and General Electric and the International Air Transport Association, which represents more than 240 airlines. \r\n<P>They said they would work towards making "meaningful benefits on tackling climate change and other environmental challenges", but did not set out any targets. \r\n<P>They plan to set up an emissions trading programme, run by the International Civil Aviation Organisation (ICAO). \r\n<P>The support for the ICAO''s scheme is a blow for the European Union''s plans to establish a regional emission trading scheme for airlines.</P></BODY></HTML>', '2008-04-22 17:58:19', 'uploads/news/4590638_airbus_ap_226b_thumb.jpg', 0, 7, 1, 0, 0);
INSERT INTO `news_news` (`id`, `writer`, `title`, `content`, `details`, `date`, `img`, `timeout`, `cat`, `views`, `votes`, `votes_total`) VALUES (28, 'BBC', 'Dull jobs really do numb the mind', '', '<HTML><HEAD></HEAD>\r\n<BODY>\r\n<P class=first><SPAN style="FONT-WEIGHT: bold">Boring jobs turn our mind to autopilot, say scientists - and it means we can seriously mess up some simple tasks. </SPAN>\r\n<P>Monotonous duties switch our brain to "rest mode", whether we like it or not, the researchers report in Proceedings of National Academy of Sciences. \r\n<P>They found mistakes can be predicted up to 30 seconds before we make them, by patterns in our brain activity. \r\n<P>The team hopes to design an early-warning brain monitor for pilots and others in "critical situations". <!-- E SF -->\r\n<P>The scientists say the device would be particularly suitable for monotonous jobs where focus is hard to maintain - such as passport and immigration control. \r\n<P><SPAN style="FONT-WEIGHT: bold">Mistakes ''foreshadowed''</SPAN> \r\n<P>"We might be able to build a device (that could be placed) on the heads of people that makes these easy decisions," said Dr Eichele, of the University of Bergen, Norway. \r\n<P>"We can measure the signal and give feedback to the user that your brain is in the state where your decisions are not going to be the right one." </P></BODY></HTML>', '2008-04-22 18:01:00', 'uploads/news/44588168_mistake66.jpg', 0, 2, 0, 0, 0);
INSERT INTO `news_news` (`id`, `writer`, `title`, `content`, `details`, `date`, `img`, `timeout`, `cat`, `views`, `votes`, `votes_total`) VALUES (29, 'BBC', 'First contact to earthquake zone', '', '<HTML><HEAD></HEAD>\r\n<BODY>\r\n<P class=first><SPAN style="FONT-WEIGHT: bold">Scientists have completed the first stage of an ambitious plan to drill down into an earthquake-generating region near Japan.</SPAN> \r\n<P>The project saw holes bored 1.4km into the sea floor, producing 3D images of stresses inside the quake zone. \r\n<P>The Nankai Trough produced major lethal earthquakes and tsunami during the last century. \r\n<P>The eventual aim is to place instruments 6km deep in the crust, possibly as an early warning system. <!-- E SF -->\r\n<P>Findings from the initial phase of the Nankai Trough Seismogenic Zone Experiment (NanTroSEIZE) were presented here at the European Geosciences Union (EGU) annual meeting. </P></BODY></HTML>', '2008-04-22 18:01:43', 'uploads/news/44579102_core66i.jpg', 0, 2, 0, 0, 0);
INSERT INTO `news_news` (`id`, `writer`, `title`, `content`, `details`, `date`, `img`, `timeout`, `cat`, `views`, `votes`, `votes_total`) VALUES (15, 'BBC', 'Brain damage link to cancer drug', '�� ���� ���� ����� ������� ������ ����� ��������� ���� ���� ��� �� �� ���� ������� ����� ��� ���� �������� ������� �� ����� ������ �� ���� �����', '<HTML><HEAD></HEAD>\r\n<BODY>\r\n<P class=first><SPAN style="FONT-WEIGHT: bold">A drug widely used to treat cancer may cause brain damage, with the effects lasting for years after the end of treatment, research suggests.</SPAN> \r\n<P>The drug, 5-fluorouracil (5-FU), is used, alongside others, to treat cancers of the breast, ovaries, colon, stomach, pancreas and bladder. \r\n<P>Tests on mice showed it destroys vital cells in the brain that help to keep nerves functioning properly. \r\n<DIV>The University of Rochester study features in the Journal of Biology.</DIV>\r\n<DIV>&nbsp;</DIV>\r\n<DIV>\r\n<P>The researchers say their findings could explain some of the neurological side effects associated with chemotherapy - a phenomenon often known as "chemo brain". \r\n<P>These include memory loss, poor concentration, and in more extreme cases, seizures, impaired vision and even dementia. \r\n<P>Until recently they were often dismissed as the by-products of fatigue, depression and anxiety related both to the diagnosis and treatment of cancer. \r\n<P>But many patients show symptoms: a previous study by the Rochester team found more than 80% of breast cancer patients reported some form of mental impairment after chemotherapy. \r\n<P><SPAN style="FONT-WEIGHT: bold">Protective sheath</SPAN> \r\n<P>The latest study found 5-FU attacks oligodendrocyte cells in the brain and the precursor stem cells from which they originate. \r\n<P>These cells play a crucial role in the central nervous system, producing myelin, the protective sheath that keeps nerve fibres in working order. \r\n<P>If myelin is not constantly renewed, communication between nerve cells is damaged. \r\n<P>The researchers showed that oligodendrocytes virtually disappeared from the brains of mice six months after the animals were treated with 5-FU. </P></DIV></BODY></HTML>', '2007-01-05 00:29:12', 'uploads/news/44589152_chemo66.jpg', 0, 10, 7, 0, 0);
INSERT INTO `news_news` (`id`, `writer`, `title`, `content`, `details`, `date`, `img`, `timeout`, `cat`, `views`, `votes`, `votes_total`) VALUES (16, 'BBC', 'Face creams under the microscope ', '���� ������� ��� ���� ����� ��� ����� ��� ������� �������� �� ������ ��� ���� ���� ���� ������� �������� ������ ����� ���� ������ ������ �� ���� ����� �� �� ����� ���� �� ���ѡ ��� �� ���� ������ �������� ������� ����ߡ ������ ������', '<HTML><HEAD></HEAD>\r\n<BODY>\r\n<P class=first><SPAN style="FONT-WEIGHT: bold">An "unprecedented" clinical trial on a high street anti-ageing cream may change the face of the skin care market in this country, dermatologists say.</SPAN> \r\n<P>At present there is a lack of clinical data to prove which creams really do slow down the skin''s ageing process. \r\n<P>Industry is thought to have shied away from major trials in part for fear products, if effective, could then be deemed medicines and tightly regulated. \r\n<P>But the trial on a Boots moisturiser may prove if these fears are founded. <!-- E SF -->\r\n<DIV>There was a run on the chain''s No. 7 Protect &amp; Perfect Beauty Serum after the BBC''s Horizon programme last year suggested it might be one of the more effective creams on the market. </DIV>\r\n<DIV>&nbsp;</DIV>\r\n<DIV>\r\n<P>Chris Griffiths, professor of dermatology at the University of Manchester, has just concluded a clinical trial on the lotion, involving 60 volunteers over a period of six months. \r\n<P>The data is now being analysed before being submitted to a scientific journal for peer review - in what is thought to be an unprecedented process for a high street skin care product. \r\n<P>"If it is proven to work - and there is certainly no guarantee that''s what we''ll find - then the debate will start on whether there is a point at which a cream is so effective it becomes a medicine," he says. \r\n<P>The active ingredients in the cream include white lupin - a flower extract - and retinyl palmitate, on top of a plain moisturising base. The trial will not establish which, if any, is effective, but how the combination works together. </P></DIV></BODY></HTML>', '2007-01-05 00:30:58', 'uploads/news/42731719_face_6649.jpg', 0, 10, 4, 1, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `news_new_menu`
-- 

CREATE TABLE `news_new_menu` (
  `id` int(11) NOT NULL auto_increment,
  `news_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=28 ;

-- 
-- Dumping data for table `news_new_menu`
-- 

INSERT INTO `news_new_menu` (`id`, `news_id`) VALUES (24, 24);
INSERT INTO `news_new_menu` (`id`, `news_id`) VALUES (25, 25);
INSERT INTO `news_new_menu` (`id`, `news_id`) VALUES (26, 26);
INSERT INTO `news_new_menu` (`id`, `news_id`) VALUES (27, 16);

-- --------------------------------------------------------

-- 
-- Table structure for table `news_pages`
-- 

CREATE TABLE `news_pages` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `news_pages`
-- 

INSERT INTO `news_pages` (`id`, `title`, `content`, `active`) VALUES (1, 'Demo Page', '<center> This is a Demo page \r\n<?\r\nprint "with php code support " ;\r\n?>\r\n</center>', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `news_phrases`
-- 

CREATE TABLE `news_phrases` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `value` text NOT NULL,
  `cat` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=284 ;

-- 
-- Dumping data for table `news_phrases`
-- 

INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (3, 'the_news_count', 'News Count', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (5, 'last_update', 'Last Update', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (6, 'contact_us', 'Contact Us', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (7, 'no_results', 'No Results', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (8, 'search_results', 'Search Results', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (12, 'send2friend', 'Send to Friend', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (42, 'the_date', 'Date', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (16, 'err_no_page', 'Invalid Page Link', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (17, 'type_search_keyword', 'Please type search keyword , Minimum {letters} Letters', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (18, 'the_name', 'Name', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (19, 'add_date', 'Add Date', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (45, 'err_no_news', 'No News', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (21, 'err_wrong_url', 'Invalid Link', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (22, 'err_no_cats', 'No Categories', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (41, 'the_news', 'News', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (24, 'pages', 'Pages', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (46, 'photos_album', 'Photo Album', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (26, 'the_writer', 'Writer', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (27, 'the_news_archive', 'News Archive', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (44, 'view_do', 'View', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (43, 'the_all', 'All', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (30, 'vote_select', 'Vote', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (31, 'vote_do', 'Do', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (32, 'send2friend_subject', 'Invite From Your Friend', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (33, 'send2friend_done', 'Invite Sent', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (34, 'your_name', 'Your Name', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (35, 'your_email', 'Your Email', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (36, 'your_friend_email', 'Your Friend', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (37, 'send', 'Send', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (38, 'err_vote_expire_hours', 'Sorry , You Can Vote Every {vote_expire_hours} Hour', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (39, 'err_no_photos', 'This Category is Empty', 'photos');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (47, 'vote_news_thnx_msg', 'Vote Done , Thank You', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (48, 'vote_news', 'Vote News', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (49, 'site_closed_for_visitors', 'Site Closed For Visitors Now', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (50, 'more', 'More', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (51, 'photos_dir', 'Photo Album', 'photos');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (52, 'photos_add_limit', 'Photos add Limit', 'photos');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (53, 'photos_thumb_width', 'Photos Thumb Width', 'photos');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (54, 'photos_thumb_hieght', 'Photos Thumb Height', 'photos');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (55, 'photos_perpage', 'Photos Per Page', 'photos');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (56, 'photos_cells', 'Photos Cells', 'photos');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (58, 'edit', 'Edit', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (59, 'the_file', 'File', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (60, 'error', 'Error', 'main');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (62, 'this_filetype_not_allowed', 'File Type Not Allowed', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (63, 'add_cat', 'Add Category', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (64, 'the_image', 'The Picture', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (65, 'add_button', 'Add', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (66, 'main_page', 'Main Page', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (67, 'cats', 'Categories', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (68, 'delete', 'Delete', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (69, 'no_subcats', 'There are no Sub-Categories', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (70, 'click_here_to_add_photos', 'Add Photos', 'photos');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (71, 'photos_edit_comment', 'Edit Comment', 'photos');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (72, 'no_files', 'There are no Files', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (73, 'browse_and_upload_photo', 'Browse & Upload', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (74, 'fields_count', 'Fields Count', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (75, 'photos_allowed_types', 'Photos Allowed Types', 'photos');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (76, 'photos_the_comment', 'Comment', 'photos');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (77, 'the_events', 'Events', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (78, 'the_events_types', 'Events Types', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (79, 'event_not_exists', 'This Event is not Exist', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (80, 'no_events', 'No Events', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (81, 'january', 'Hanuary', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (82, 'february', 'February', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (83, 'march', 'March', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (84, 'april', 'April', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (85, 'may', 'May', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (86, 'june', 'June', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (87, 'july', 'July', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (88, 'august', 'August', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (89, 'september', 'September', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (90, 'october', 'October', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (91, 'november', 'November', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (92, 'december', 'December', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (93, 'events_prev', 'Prev', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (94, 'events_next', 'Next', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (95, 'add_event', 'Add Event', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (96, 'the_title', 'Title', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (97, 'the_type', 'Type', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (98, 'without', 'Without', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (99, 'the_content', 'Content', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (100, 'events_no_types', 'No Types', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (101, 'events_add', 'Add', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (102, 'the_color', 'Color', 'events');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (103, 'err_wrong_password', 'Invalid Password', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (104, 'err_wrong_username', 'Invalid Username', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (105, 'welcome_to_cp', 'Welcome To Control Panel', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (106, 'cp_user_welcome', 'Welcome ', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (107, 'cp_statics', 'Statics', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (108, 'cp_main_cats_count', 'Main Categories', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (109, 'cp_sub_cats_count', 'Sub Categories', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (110, 'cp_news_count', 'News ', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (111, 'cp_users_count', 'Users', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (112, 'php_version', 'PHP Version', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (113, 'mysql_version', 'MySQL Version', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (114, 'zend_version', 'Zend Optimizer Version', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (115, 'the_version', 'Version', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (116, 'cp_available', 'Available', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (117, 'cp_not_available', 'Not Available', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (118, 'gd_library', 'GD Library', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (119, 'gd_install_required', 'You must install GD Library.', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (120, 'cp_addons', 'Plugins', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (121, 'err_wrong_uploader_folder', 'Not Valid Upload Folder', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (122, 'upload_file_do', 'Upload', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (123, 'allowed_filetypes', 'Allowed Types', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (124, 'please_login_first', 'Please Login First', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (125, 'auto_photos_resize', 'Auto Photos Resize', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (126, 'cp_manage_news', 'News', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (127, 'cp_selected_news', 'Custom List', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (128, 'the_blocks', 'Blocks', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (129, 'the_votes', 'Votes', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (130, 'the_pages', 'Pages', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (131, 'the_banners', 'Banners', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (132, 'the_statics_and_counters', 'Statics & Counters', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (133, 'the_templates', 'Templates', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (134, 'the_phrases', 'Phrases', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (135, 'the_settings', 'Settings', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (136, 'the_database', 'Database', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (137, 'backup', 'Backup', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (138, 'users_and_permissions', 'Users & Permissions', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (139, 'logout', 'Logout', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (140, 'cats_list', 'Categories List', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (141, 'select_this_cat', 'Select This Category', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (142, 'process_done', 'Process Done', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (143, 'the_position', 'Position', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (144, 'right', 'Right', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (145, 'center', 'Center', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (146, 'left', 'Left', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (147, 'the_template', 'Template', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (148, 'the_default_template', 'Default Template', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (149, 'the_order', 'Order', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (150, 'appearance_places', 'Appearance Places', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (151, 'the_options', 'Options', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (152, 'to_up', 'To Up', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (153, 'to_down', 'To Down', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (154, 'enable', 'Enable', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (155, 'disable', 'Disable', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (156, 'cp_blocks_fix_order', 'Fix Order', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (157, 'cp_no_blocks', 'No Blocks', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (158, 'add_new_vote', 'Add New Vote', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (159, 'default', 'Default', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (160, 'set_default', 'Set as Default', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (161, 'edit_and_options', 'Edit / Options', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (162, 'add_options', 'Add Options', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (163, 'err_cat_access_denied', 'You Don', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (164, 'err_invalid_cat_id', 'Error , Invalid Category ID', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (165, 'cp_news_cat_del_confirm', 'Warning : Deleting This Category will Delete all News Inside it , Continue ?', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (166, 'cp_news_add', 'Add News', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (167, 'cp_check_all', 'Check All', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (168, 'cp_uncheck_all', 'Un-Check All', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (169, 'move', 'Move', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (170, 'do_button', 'Do', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (171, 'are_you_sure', 'Are You Sure ?', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (172, 'cp_no_news', 'No News', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (173, 'move_from', 'Move From', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (174, 'move_to_cat_number', 'Move to Category #', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (175, 'the_cats_list', 'Categories List', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (176, 'move_news_button', 'Move News', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (177, 'please_select_news_first', 'Please Select News First', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (178, 'cp_view_page', 'View Page', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (179, 'cp_no_pages', 'No Pages', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (180, 'permissions_manage', 'Permissions Manage', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (181, 'news_cats_permissions', 'News Categories Permissions', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (182, 'cp_sections_permissions', 'Sections Permissions', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (183, 'cp_err_username_exists', 'Error , Username Exists', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (184, 'err_access_denied', 'Access Denied', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (185, 'cp_plz_enter_usr_pwd', 'Please Enter Username & Password', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (186, 'cp_edit_user_success', 'Edit Success', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (187, 'cp_add_user', 'Add User', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (188, 'cp_username', 'Username', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (189, 'cp_password', 'Password', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (190, 'cp_email', 'Email', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (191, 'cp_user_group', 'Group', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (192, 'cp_user_admin', 'Administrator', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (193, 'cp_user_mod', 'Moderator', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (194, 'the_users', 'Users', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (195, 'edit_personal_acc_only', 'You Can Only Edit Your Own Account ', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (196, 'click_here_to_edit_ur_account', 'To Edit Your Account Click Here', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (197, 'leave_blank_for_no_change', 'leave Blank for no change', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (198, 'the_content_type', 'Content Type', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (199, 'the_url', 'URL', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (200, 'bnr_appearance_places', 'Apperance Place', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (201, 'bnr_appearance_pages', 'Apperance Pages', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (202, 'add_after_menu_number', 'Add After Menu #', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (203, 'login_do', 'Login', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (204, 'bnr_ctype_code', 'Code', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (205, 'bnr_ctype_img', 'Image/Link', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (206, 'the_code', 'Code', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (207, 'bnr_open', 'pop-up on Open', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (208, 'bnr_close', 'pop-up on Close', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (209, 'bnr_menu', 'Menu Banner', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (210, 'bnr_header', 'Header Banner', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (211, 'bnr_footer', 'Footer Banner', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (212, 'bnr_menu_pos', 'On', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (213, 'the_left', 'The Left', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (214, 'the_center', 'The Center', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (215, 'the_right', 'The Right', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (216, 'bnr_the_menu', 'Menu', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (217, 'bnr_the_visits', 'Visits', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (218, 'bnr_appearance_count', 'Views', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (219, 'cp_add_new_template', 'Add New Template', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (220, 'the_description', 'Description', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (221, 'cp_edit_templates', 'Edit Templates', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (222, 'cp_the_sitename', 'Site Name', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (223, 'cp_the_section_name', 'Section Name', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (224, 'cp_copyrights_sitename', 'Site Name in Copyrights', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (225, 'cp_the_page_dir', 'Page Direction', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (226, 'right_to_left', 'Right to Left', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (227, 'left_to_right', 'Left to Right', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (228, 'cp_header_keywords', 'Keywords', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (229, 'cp_enable_browsing', 'Enable Browsing', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (230, 'cp_opened', 'Opened', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (231, 'cp_closed', 'Closed', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (232, 'cp_browsing_closing_msg', 'Close Message', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (233, 'cp_statics_system', 'Statics System', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (234, 'enabled', 'Enabled', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (235, 'disabled', 'Disabled', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (236, 'cp_count_online_visitors', 'Count Online Visitors', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (237, 'cp_add_news_fields_count', 'News Add Fields Count', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (238, 'cp_news_perpage', 'News Per Page', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (239, 'cp_news_cells', 'News Cells', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (240, 'news_votes_time_limit', 'News Votes timeout', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (241, 'hour', 'Hour', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (242, 'votes_time_limit', 'Votes timeout', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (243, 'cp_search_min_letters', 'Minimum Search Letters', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (244, 'uploader_thumb_width', 'Uploader Thumb Width', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (245, 'uploader_thumb_hieght', 'Uploader Thumb Height', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (246, 'pixel', 'Pixel', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (248, 'cp_uploader_system', 'Uploader System', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (249, 'cp_uploader_disable_msg', 'Disable Message', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (250, 'cp_uploader_path', 'Upload Path', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (251, 'cp_uploader_allowed_types', 'Allowed Types', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (252, 'cp_db_backup', 'Database Backup', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (253, 'db_backup_saveto_pc', 'Save On Your Computer', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (254, 'db_backup_saveto_server', 'Save On Server', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (255, 'the_file_path', 'File Path', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (256, 'cp_db_backup_do', 'Process', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (257, 'the_size', 'Size', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (258, 'the_table', 'Table', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (259, 'the_status', 'Status', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (260, 'db_repair_tables_do', 'Repair Tables', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (261, 'pleas_select_tables_to_rapair', 'Please Select Tables', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (262, 'cp_repairing_table', 'Repairing Table', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (263, 'done', 'Done', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (264, 'visitors_statics_rest_done', 'Visitors Statics Rest Done', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (265, 'news_statics_rest_done', 'News Views Statics Rest Done', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (266, 'news_votes_rest_done', 'News Votes Statics Rest Done', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (267, 'cp_visitors_statics', 'Visitors Statics', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (268, 'cp_counters_start_date', 'Start Date', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (269, 'cp_total_visits', 'Total Visits', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (270, 'cp_rest_counters', 'Rest Counters', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (271, 'cp_news_view_statics', 'News Views', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (272, 'cp_news_votes_statics', 'News Votes', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (273, 'cp_rest_counters_do', 'Rest Counters', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (274, 'err_wrong_news_id', 'Error , Invalid News ID', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (275, 'cp_news_id', 'News ID', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (276, 'cp_no_phrases', 'No Phrases', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (277, 'err_function_usage_denied', '<b> Error : </b>  You can', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (278, 'err_wrong_img_type', 'Invalid Photo Type', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (279, 'please_enter_the_name', 'Please Enter Name', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (280, 'the_news_list', 'News List', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (281, 'browsing_news', 'Browsing News', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (282, 'the_search', 'Search', 'cp');
INSERT INTO `news_phrases` (`id`, `name`, `value`, `cat`) VALUES (283, 'the_statics', 'Statics', 'cp');

-- --------------------------------------------------------

-- 
-- Table structure for table `news_phrases_cats`
-- 

CREATE TABLE `news_phrases_cats` (
  `id` text NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY  (`id`(20))
) ENGINE=MYISAM;

-- 
-- Dumping data for table `news_phrases_cats`
-- 

INSERT INTO `news_phrases_cats` (`id`, `name`) VALUES ('main', 'General');
INSERT INTO `news_phrases_cats` (`id`, `name`) VALUES ('cp', 'System & Control Panel');
INSERT INTO `news_phrases_cats` (`id`, `name`) VALUES ('photos', 'Photo Album');
INSERT INTO `news_phrases_cats` (`id`, `name`) VALUES ('events', 'Events');

-- --------------------------------------------------------

-- 
-- Table structure for table `news_settings`
-- 

CREATE TABLE `news_settings` (
  `name` text NOT NULL,
  `value` text NOT NULL
) ENGINE=MYISAM;

-- 
-- Dumping data for table `news_settings`
-- 

INSERT INTO `news_settings` (`name`, `value`) VALUES ('snd2friend', '1');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('vote_song', '1');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('sitename', 'Allomani');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('section_name', 'News');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('news_add_fields', '5');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('letters_songs', '1');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('letters_singers', '1');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('html_dir', 'ltr');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('header_keywords', 'News');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('uploader', '0');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('uploader_path', 'uploads');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('uploader_msg', 'Sorry , Uploading Files disabled in Demo Version');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('uploader_types', 'jpg,gif,png');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('news_add_limit', '10');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('singers_groups', '1');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('news_perpage', '10');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('news_cells', '4');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('vote_clip', '');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('snd2friend_clip', '');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('votes_expire_hours', '24');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('copyrights_sitename', 'Allomani');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('search_min_letters', '3');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('photos_add_limit', '20');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('photos_thumb_width', '100');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('photos_thumb_hieght', '100');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('photos_perpage', '30');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('photos_cells', '3');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('vote_file_expire_hours', '21');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('enable_browsing', '1');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('disable_browsing_msg', '<center> Sorry , site closed at this time</center>');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('uploader_thumb_width', '100');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('uploader_thumb_hieght', '100');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('statics_system_enable', '1');
INSERT INTO `news_settings` (`name`, `value`) VALUES ('online_visitors_enable', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `news_templates`
-- 

CREATE TABLE `news_templates` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `name` text NOT NULL,
  `content` text NOT NULL,
  `protected` int(11) NOT NULL default '0',
  `type` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=22 ;

-- 
-- Dumping data for table `news_templates`
-- 

INSERT INTO `news_templates` (`id`, `title`, `name`, `content`, `protected`, `type`) VALUES (1, 'Header', 'header', '<BODY onunload="pop_close()"  bgColor=#ffffff\r\nleftMargin=0 topMargin=0>\r\n		\r\n		<TABLE class=dcitb cellSpacing=0 cellPadding=0 width="100%" border=0>\r\n  <TBODY>\r\n  <TR>\r\n    <TD vAlign=top align=left background=images/murabba_full_03.gif width="100%">  \r\n      <img border="0" src="images/logo.gif"></TD>\r\n    <TD vAlign=bottom align=left background=images/murabba_full_03.gif width="158">  \r\n	</TD>\r\n    <TD vAlign=top background=images/murabba_full_03.gif>\r\n      &nbsp;<p>&nbsp;</TD></TR>\r\n  <TR>\r\n    <TD vAlign=top width="100%" colSpan=3>\r\n      <TABLE class=dcitb cellSpacing=0 cellPadding=0 width="100%"       background=images/murabba_full_05.gif border=0>\r\n        <TBODY>\r\n        <TR>\r\n          <TD class=tdr width="100%" height=20>\r\n</TD></TR></TBODY></TABLE>\r\n				        \r\n        \r\n        \r\n        \r\n        \r\n        ', 1, 'html');
INSERT INTO `news_templates` (`id`, `title`, `name`, `content`, `protected`, `type`) VALUES (20, 'Page Head', 'page_head', '<?\r\nglobal $settings;\r\nprint "<META http-equiv=Content-Language content=en-us>\r\n<META http-equiv=Content-Type content=\\"text/html; charset=windows-1252\\">\r\n<META name=keywords content=\\"allomani, allomani.biz , $settings[header_keywords]\\" >\r\n<LINK href=\\"style.css\\" type=text/css rel=StyleSheet>";\r\n?>\r\n<script type="text/javascript" src="js/prototype.js"></script>\r\n<script type="text/javascript" src="js/balloon.js"></script>\r\n<script type="text/javascript" src="js/yahoo-dom-event.js"></script>\r\n<script type="text/javascript" src="js/global.js"></script>\r\n<script type="text/javascript" > var balloon = new Balloon;</script>\r\n\r\n', 1, 'php');
INSERT INTO `news_templates` (`id`, `title`, `name`, `content`, `protected`, `type`) VALUES (2, 'Footer', 'footer', '<br><br><TABLE class=dcitb cellPadding=0 width="100%" border=0>\r\n  <TBODY>\r\n  <TR>\r\n    <TD vAlign=top background=images/murabba_full_05.gif height=10 colspan=2>&nbsp;</TD></TR>\r\n  <TR><!-- footer menu-->\r\n    <TD align=center dir=rtl vAlign=top background="">\r\n      <DIV style="MARGIN: 5px 0px"><a href="index.php">Home</a>&nbsp; <SPAN \r\n      class=clr2>&#3663;</SPAN> <a href="browse.html">News</a> <SPAN class=clr2>&#3663;</SPAN>&nbsp;\r\n		<a href="index.php?action=browse_events">Events</a> <SPAN class=clr2>&#3663;</SPAN> \r\n		<a href="index.php?action=contactus">Contact US</a></DIV></TD></TR></TBODY></TABLE><!-- footer end--></DIV></BODY></HTML>\r\n        \r\n        \r\n\r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        ', 1, 'html');
INSERT INTO `news_templates` (`id`, `title`, `name`, `content`, `protected`, `type`) VALUES (3, 'Blocks', 'block', '<center><table dir="ltr" cellSpacing="0" cellPadding="0"  border="0" id="table7">\r\n                                                                <tr>\r\n                                                                        <td width="2%" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box1.gif" width="21"></td>\r\n                                                                        <td width="95%" background="images/box2.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box2.gif" width="4"></td>\r\n                                                                        <td width="3%" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box3.gif" width="21"></td>\r\n                                                                </tr>\r\n                                                                <tr>\r\n                                                                        <td background="images/box4.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="35" src="images/box4.gif" width="20"></td>\r\n                                                                        <td dir="ltr" bgColor="#F9F9F9" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <div align="center" dir="ltl">\r\n                                                                                <table dir="ltl" cellSpacing="4" cellPadding="0" width="100%" align="center" border="0" id="table8">\r\n                                                                                        <tr>\r\n                                                                                                <td width="100%" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                                              {title}{new_line}\r\n{content}\r\n\r\n</td>\r\n                                                                                        </tr>\r\n                                                                                </table></div></td>\r\n                                                                        <td background="images/box5.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="8" src="images/box5.gif" width="21"></td>\r\n                                                                </tr>\r\n                                                                <tr>\r\n                                                                        <td style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box6.gif" width="21"></td>\r\n                                                                        <td background="images/box7.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box7.gif" width="3"></td>\r\n                                                                        <td style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box8.gif" width="21"></td>\r\n                                                                </tr>\r\n                                                        </table><br></center>\r\n        \r\n        \r\n        ', 1, 'html');
INSERT INTO `news_templates` (`id`, `title`, `name`, `content`, `protected`, `type`) VALUES (4, 'Tables', 'table', '<center>\r\n                                                        <table dir="ltr" cellSpacing="0" cellPadding="0"  border="0" id="table7">\r\n                                                                <tr>\r\n                                                                        <td width="2%" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box1.gif" width="21"></td>\r\n                                                                        <td width="95%" background="images/box2.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box2.gif" width="4"></td>\r\n                                                                        <td width="3%" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box3.gif" width="21"></td>\r\n                                                                </tr>\r\n                                                                <tr>\r\n                                                                        <td background="images/box4.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="35" src="images/box4.gif" width="20"></td>\r\n                                                                        <td dir="ltr" bgColor="#F9F9F9" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <div align="center" dir="ltr">\r\n                                                                                <table dir="ltl" cellSpacing="4" cellPadding="0" width="100%" align="center" border="0" id="table8">\r\n                                                                                        <tr>\r\n                                                                                                <td width="100%" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                               {title}\r\n{new_line}\r\n                \r\n{content}\r\n\r\n</td>\r\n                                                                                        </tr>\r\n                                                                                </table></div></td>\r\n                                                                        <td background="images/box5.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="8" src="images/box5.gif" width="21"></td>\r\n                                                                </tr>\r\n                                                                <tr>\r\n                                                                        <td style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box6.gif" width="21"></td>\r\n                                                                        <td background="images/box7.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box7.gif" width="3"></td>\r\n                                                                        <td style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box8.gif" width="21"></td>\r\n                                                                </tr>\r\n                                                        </table><br></center>\r\n        \r\n        ', 1, 'html');
INSERT INTO `news_templates` (`id`, `title`, `name`, `content`, `protected`, `type`) VALUES (5, 'Contact Us', 'contactus', '        <center> You Can Change This Text From Templates in Script''s Control Panel</center>\r\n        ', 1, 'html');
INSERT INTO `news_templates` (`id`, `title`, `name`, `content`, `protected`, `type`) VALUES (6, 'Send to Friend Message', 'friend_msg', '<html dir="ltr">\r\n\r\n<head>\r\n<meta http-equiv="Content-Type" content="text/html; charset=windows-1256">\r\n<meta http-equiv="Content-Language" content="ar-sa">\r\n</head>\r\n\r\n<p>Your Friend {name_from} Sent This News For You : </p>\r\n\r\n\r\n{title} <br><br>\r\n\r\nVisit : <br> {url}\r\n\r\n\r\n</html>\r\n\r\n        \r\n        \r\n        \r\n        \r\n        \r\n        ', 1, 'html');
INSERT INTO `news_templates` (`id`, `title`, `name`, `content`, `protected`, `type`) VALUES (15, 'News - Outside', 'browse_news', '<table width=100%><tr><td width=20% valign=top align=center><img src=''{img}''></td>\r\n<td><center><font color=''#808080'' class=''title''>{title}</font></center><br>\r\n<font color=''#808080''>{date} : </font> {content} ... <a href=''news-{id}.html''>More </a>\r\n<br><br> Writer : <font color=''#808080''>{writer}</font></td></tr></table>\r\n        \r\n        \r\n        \r\n        ', 1, 'html');
INSERT INTO `news_templates` (`id`, `title`, `name`, `content`, `protected`, `type`) VALUES (16, 'News - Inside', 'browse_news_inside', '<table width=100%><tr><td dir=ltr>\r\n\r\n<DIV style="FLOAT: right"><TABLE border="0"><TBODY><TR><TD><TABLE border="0"><TBODY><TR><TD align="center">\r\n<img src=''{img}''>\r\n</TD></TR><TR><TD align=center><font color=''#808080''>{date} </font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir="ltl" align="left">\r\n{details} <br><br> Writer : <font color=''#808080''>{writer}</font>\r\n\r\n</td></tr>\r\n<tr><td colspan=2 align=right><a href=''print.php?id={id}''><img src=''images/print.gif'' alt=''Print'' border=0></a> <a href=''javascript:vote({id})''><img src=''images/vote.gif'' alt=''Vote'' border=0></a>\r\n<a href=''javascript:snd({id})''><img src=''images/snd.gif'' alt=''Send to Friend'' border=0></a>\r\n\r\n\r\n</div>\r\n\r\n</td></tr></table>\r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        ', 1, 'html');
INSERT INTO `news_templates` (`id`, `title`, `name`, `content`, `protected`, `type`) VALUES (8, 'Windows js Functions', 'js_functions', '<script>\r\nfunction snd(id)\r\n{\r\n\r\nmsgwindow=window.open("send2friend.php?id="+id,"displaywindow","toolbar=no,scrollbars=no,width=350,height=300,top=200,left=200")\r\n}\r\n\r\n\r\n\r\nfunction vote(id)\r\n{\r\n\r\nmsgwindow=window.open("vote.php?id="+id,"displaywindow","toolbar=no,scrollbars=no,width=350,height=250,top=200,left=200")\r\n}\r\n\r\n </script>\r\n        \r\n        \r\n        \r\n        ', 1, 'html');
INSERT INTO `news_templates` (`id`, `title`, `name`, `content`, `protected`, `type`) VALUES (17, 'News - Print', 'browse_news_print', '<html dir=ltr>\r\n<title>{title}</title>\r\n\r\n<table width=100%>\r\n<tr>\r\n<td>\r\n<p align=center><font size=5><b>{title}</b></font></p>\r\n</td></tr>\r\n\r\n<tr><td>\r\n\r\n<DIV style="FLOAT: right"><TABLE border="0"><TBODY><TR><TD><TABLE border="0"><TBODY><TR><TD align="center">\r\n<img src=''{img}''>\r\n</TD></TR><TR><TD align=center><font color=''#808080''>{date} </font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir="ltr" align="left">\r\n{details} <br><br> Writer : <font color=''#808080''>{writer}</font>\r\n</div>\r\n</td></tr>\r\n\r\n</table>\r\n        \r\n\r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        ', 1, 'html');
INSERT INTO `news_templates` (`id`, `title`, `name`, `content`, `protected`, `type`) VALUES (18, 'Fonts size and colors', 'CSS', '/*--------- BODY ----------*/\r\nBODY {\r\nFONT-SIZE: 8pt; COLOR: #1266a5 ; FONT-FAMILY: Tahoma; \r\nSCROLLBAR-FACE-COLOR: #ffffff; SCROLLBAR-SHADOW-COLOR: #277eb3; \r\nSCROLLBAR-3DLIGHT-COLOR: #ffffff; SCROLLBAR-ARROW-COLOR: #277eb3; \r\nSCROLLBAR-TRACK-COLOR: #ffffff; SCROLLBAR-DARKSHADOW-COLOR: #ffffff; \r\nBACKGROUND-COLOR: #ffffff; \r\naSCROLLBAR-HIGHLIGHT-COLOR: #ffffff\r\n\r\n}\r\n\r\nFONT {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n	}\r\n\r\nTD {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n}\r\n\r\n\r\nP {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n}\r\n\r\nDIV {\r\nFONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n}\r\n\r\n/*-------------- TITLES FONT----------------*/\r\n.title {\r\n	FONT-SIZE: 10pt; BACKGROUND: ; COLOR: #215dc6; FONT-FAMILY: Tahoma; TEXT-DECORATION: none; font-weight:bold\r\n}\r\n    \r\n/*----------- LINKS ------------------*/\r\nA:link {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\n\r\n\r\nA:active {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n\r\n}\r\nA:visited {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\nA:hover {\r\n	FONT-SIZE: 8pt; COLOR: #007CF9; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\n\r\n\r\n/*--------- PATH BAR LINKS ----------*/\r\nA:link.path_link {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\nA:active.path_link {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n\r\n}\r\nA:visited.path_link {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\nA:hover.path_link {\r\n	FONT-SIZE: 8pt; COLOR: #007CF9; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\n\r\n', 1, 'html');
INSERT INTO `news_templates` (`id`, `title`, `name`, `content`, `protected`, `type`) VALUES (19, 'Browse Categories', 'browse_cats', '<center><a href=''browse_{id}.html''>\r\n            <img border=0 src=''images/folder.gif''>\r\n<br>{name}</a>\r\n\r\n </center>  ', 1, 'html');

-- --------------------------------------------------------

-- 
-- Table structure for table `news_user`
-- 

CREATE TABLE `news_user` (
  `id` int(11) NOT NULL auto_increment,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `group_id` int(11) NOT NULL default '0',
  `permisions` text NOT NULL,
  `cp_permisions` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `news_user`
-- 

INSERT INTO `news_user` (`id`, `username`, `password`, `email`, `group_id`, `permisions`, `cp_permisions`) VALUES (1, 'admin', 'admin', 'info@allomani.com', 1, '', '');
INSERT INTO `news_user` (`id`, `username`, `password`, `email`, `group_id`, `permisions`, `cp_permisions`) VALUES (9, 'mod', 'mod', 'info@allomani.biz', 2, '2', 'new_menu,templates,phrases,');

-- --------------------------------------------------------

-- 
-- Table structure for table `news_votes`
-- 

CREATE TABLE `news_votes` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `cnt` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `news_votes`
-- 

INSERT INTO `news_votes` (`id`, `title`, `cnt`, `cat`) VALUES (1, 'Good', 18, 1);
INSERT INTO `news_votes` (`id`, `title`, `cnt`, `cat`) VALUES (2, 'Not Bad', 2, 1);
INSERT INTO `news_votes` (`id`, `title`, `cnt`, `cat`) VALUES (3, 'Bad', 1, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `news_votes_cats`
-- 

CREATE TABLE `news_votes_cats` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `news_votes_cats`
-- 

INSERT INTO `news_votes_cats` (`id`, `title`, `active`) VALUES (1, 'What are you think about website ?', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `photos_cats`
-- 

CREATE TABLE `photos_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `img` text NOT NULL,
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=11 ;

-- 
-- Dumping data for table `photos_cats`
-- 

INSERT INTO `photos_cats` (`id`, `name`, `img`, `cat`) VALUES (9, 'Demo Category', '', 0);
INSERT INTO `photos_cats` (`id`, `name`, `img`, `cat`) VALUES (10, 'Demo Category 2', '', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `photos_data`
-- 

CREATE TABLE `photos_data` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `img` text NOT NULL,
  `thumb` text NOT NULL,
  `cat` int(11) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=31 ;

-- 
-- Dumping data for table `photos_data`
-- 

INSERT INTO `photos_data` (`id`, `name`, `img`, `thumb`, `cat`, `date`) VALUES (27, 'Jeddah', 'uploads/photos/101.jpg', 'uploads/photos/101_thumb.jpg', 9, '2008-03-26 07:21:52');
INSERT INTO `photos_data` (`id`, `name`, `img`, `thumb`, `cat`, `date`) VALUES (28, 'Mamlakah Tower', 'uploads/photos/kingdomcenter-tower_800.jpg', 'uploads/photos/kingdomcenter-tower_800_thumb.jpg', 9, '2008-03-26 07:21:52');
INSERT INTO `photos_data` (`id`, `name`, `img`, `thumb`, `cat`, `date`) VALUES (29, '', 'uploads/photos/gallery61_jpg.jpg', 'uploads/photos/gallery61_jpg_thumb.jpg', 9, '2008-03-26 07:21:52');
INSERT INTO `photos_data` (`id`, `name`, `img`, `thumb`, `cat`, `date`) VALUES (30, '', 'uploads/photos/gallery77_jpg.jpg', 'uploads/photos/gallery77_jpg_thumb.jpg', 9, '2008-03-26 07:21:52');
